import React from 'react'

export const DnDContext = React.createContext()
